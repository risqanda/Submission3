/* eslint-disable no-undef */
const assert = require('assert');

Feature('Liking Restaurant');

Scenario('menyukai restaurant', async ({ I }) => {
// Visit the home page
  I.amOnPage('/');
  // Wait for the list of restaurants to appear
  I.waitForElement('.card-content .card-details a');
  // Select the first restaurant
  const firstRestaurant = locate('.card-content .card-details a').first();
  // Click the first restaurant
  I.click(firstRestaurant);
  // On the detail page, find and click the like button
  I.waitForElement('#likeButton');
  I.seeElement('#likeButton');
  I.click('#likeButton');
  // Go to the favorite page and ensure that the liked restaurant is displayed
  I.amOnPage('#/favorite');
  I.waitForElement('.card-content .card-details a');
  // Make sure the restaurant that appears on the favorite page is the same as the liked restaurant
  const firstRestaurantName = await I.grabTextFrom(firstRestaurant);
  const favoritedRestaurantName = await I.grabTextFrom('.card-content .card-details a');
  assert.strictEqual(firstRestaurantName, favoritedRestaurantName);
});

Scenario('batal menyukai restaurant', async ({ I }) => {
// Visit the favorite page
  I.amOnPage('/#/favorite');
  // Make sure no restaurants are displayed
  I.dontSeeElement('.card-content .card-details a');
  // Go back to the home page
  I.amOnPage('/');
  // Wait for 5 seconds
  I.wait(5);
  // View the restaurants
  I.waitForElement('.card-content .card-details a');
  // Select a restaurant
  const firstRestaurant = locate('.card-content .card-details a').first();
  I.click(firstRestaurant);
  // View the Like button
  I.waitForElement('#likeButton');
  I.seeElement('#likeButton');
  // Like the restaurant
  I.click('#likeButton');
  // Go to the favorite page
  I.amOnPage('#/favorite');
  // Wait for 5 seconds
  I.wait(5);
  // View the liked restaurants
  I.waitForElement('.card-content .card-details a');
  // Select the liked restaurant
  const favoritedRestaurant = locate('.card-content .card-details a').first();
  I.click(favoritedRestaurant);
  // View the Unlike button
  I.waitForElement('#likeButton');
  I.seeElement('#likeButton');
  // Unlike the restaurant
  I.click('#likeButton');
});
