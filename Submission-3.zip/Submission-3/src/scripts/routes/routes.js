/* eslint-disable linebreak-style */
import MenuApp from '../views/pages/PagesMenu';
import details from '../views/pages/PagesDetails';
import favorite from '../views/pages/PagesFavorite';

const routes = {
  '/': MenuApp,
  '/detail/:id': details,
  '/favorite': favorite,
};

export default routes;
