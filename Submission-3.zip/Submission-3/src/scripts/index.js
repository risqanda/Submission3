/* eslint-disable no-unused-vars */
import 'regenerator-runtime'; /* for async await transpile */
import '../styles/config.css';
import '../styles/main.css';
import '../styles/navbar.css';
import '../styles/drawer.css';
import '../styles/hero.css';
import '../styles/detail-resto.css';
import '../styles/fav-resto.css';
import '../styles/footer.css';
import '../styles/responsibility.css';
import '../styles/loader.css';
import '../styles/skip-to-content.css';
import '../styles/notif-resto.css';
import Apps from './views/app';
import swRegister from './utils/sw-register';
import CONFIG from './globals/config';
import { webSocketInitiator } from './utils/web-socket-initiator';
import './components/navbar';
import './components/hero';
import './components/footer';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';

const apps = new Apps({
  button: document.querySelector('#icon-mobile'),
  drawer: document.querySelector('#drawer'),
  content: document.querySelector('#main-content'),
});

window.addEventListener('hashchange', () => {
  apps.renderPage();
});

window.addEventListener('load', () => {
  apps.renderPage();
  swRegister();
  webSocketInitiator.init(CONFIG.WEB_SOCKET_SERVER);
});
