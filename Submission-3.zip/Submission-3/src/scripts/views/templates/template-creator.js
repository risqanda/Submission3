/* eslint-disable indent */
/* eslint-disable linebreak-style */
/* eslint-disable no-use-before-define */
import CONFIG from '../../globals/config';

const CreateCardResto = (create) => `
<div class="col"> 
<div class="card">
    <div class="card-image">
        <img class="lazyload" data-src="${CONFIG.BASE_IMAGE_URL}small/${create.pictureId}" alt="${create.name}"/>
    </div>
    <div class="card-content">
        <div class="card-category">${create.city}</div>
        <div class="card-rating"><a href="">Rating : &#x2b50</a>${create.rating}</div>
        <div class="card-title">${create.name}</div>
        <div class="card-description">
            <p>${create.description.slice(0, 200)}</p>
            <div class="card-details">
            <a href="${`/#/detail/${create.id}`}">Detail Restoran...</a>
            </div>
        </div>
    </div>
</div>
</div>
`;

const CreateDetailResto = (create) => `
<h2 tabindex="0" class="explore">Details Of <span>${create.name}</span></h2>
<div class="detail">
<div>
<div class="img-res2" alt="${create.name}">
<img class="lazyload" data-src="${CONFIG.BASE_IMAGE_URL}small/${create.pictureId}" crossorigin="anonymous"/>
</div>

</div>
<ul class="detail-info">
<h3><i class="fa fa-map-marker fa-md desc-icon" aria-hidden="true"></i><span class="short-title" aria-label="address at ${create.address}, ${create.city}"> ${create.address}, ${create.city}</span></h3>
<h3><i class="fa fa-list-alt fa-md desc-icon" aria-hidden="true"></i><span class="short-title" aria-label="categories"> ${create.categories.map((category) => `<span class=""> ${category.name}</span>`).join('')}</span></h3>
<h3><i class="fa fa-star fa-md desc-icon"></i><span class="short-title" aria-label="rating"> ${create.rating}</span></h3>
  <li><p class="truncate2">Description: ${create.description}</p></li>
  <li>${create.categories
    .map(
      (category) => `
        <span class="category">${category.name}</span>
      `,
    )
    .join('')}
  </li>
</ul>
<div class="restaurant-detail">
    <h2><span>Our</span> Menu</h2>
    <div class="detail-menu grid-2">
      <div class="detail-food">
        <h4>The <span>Food</span></h4>
        <ul>
          ${create.menus.foods
            .map(
              (food) => `
                <li><p>${food.name}</p></li>
              `,
            )
            .join('')}
        <ul>
      </div>
      <div class="detail-drink">
        <h4>The <span>Drink</span></h4>
        <ul>
          ${create.menus.drinks
            .map(
              (drink) => `
                <li><p>${drink.name}</p></li>
              `,
            )
            .join('')}
        <ul>
      </div>
      <div>
    <h2><span>Our</span> Reviews <span class="count">${create.customerReviews.length}</span></h2>
    <div class="card-review">
        ${CreateCardReview(create.customerReviews)}
    </div>
</div>
`;

const CreateLikeButtonTemplate = () => `
    <button aria-label="like this restaurant" id="likeButton" class="liked">
        <i class="fa fa-heart-o fa-lg" aria-hidden="true"></i>
    </button>
`;

const CreateLikedButtonTemplate = () => `
    <button aria-label="unlike this restaurant" id="likedButton" class="liked">
        <i class="fa fa-heart fa-lg" aria-hidden="true"></i>
    </button>
`;

const CreateBlankFavoriteTemplate = () => `
    <div class="blank-container">
        <p class="blank-text">Tidak ada list favoritmu disini, <span>Kuy Tambahin!</span></p>
        <a href="/">Add Favorite</a>
    </div>
`;

const CreateCardReview = (data) => {
  let customerReview = '';
  data.forEach((review) => {
    customerReview += `<div class="card-review-item">
    <div class="card-review-header">
      <p class="card-review-name"><i title="restaurant" class="fa fa-user-circle" style="font-size:1.3em;"></i>&nbsp;${review.name}</p>
      <p class="card-review-date">${review.date}</p>
    </div>
    <div class="card-review-body">
      ${review.review}
    </div>
  </div>`;
  });
  return customerReview;
};

const MyCustomLoader = () => `
    <div class="my-custom-loader"></div>
`;

const CreateSkeletonTemplate = (count) => {
  let template = '';

  for (let i = 0; i < count; i += 1) {
    template += `
        <div class="card">
            <img class="card-img" alt="skeleton">
            <div class="card-content">
                <h2 class="skeleton">Lorem ipsum dolor sit.</h2>
                <p class="skeleton"></p>
                <div class="card-desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit. A adipisci alias aspernatur, assumenda aut consectetur consequuntur debitis deleniti dicta dolorem dolorum eos exercitationem labore laboriosam magni nihil, nobis obcaecati optio perspiciatis placeat qui recusandae saepe sapiente sequi totam ullam ut.</div>
            </div>
        </div>
        `;
  }
  return template;
};

export {
  CreateCardResto,
  CreateDetailResto,
  CreateLikeButtonTemplate,
  CreateLikedButtonTemplate,
  CreateBlankFavoriteTemplate,
  CreateCardReview,
  MyCustomLoader,
  CreateSkeletonTemplate,
};
