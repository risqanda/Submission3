/* eslint-disable linebreak-style */
import urlParser from '../../routes/url-parser';
import KuyRestoSource from '../../data/KuyResto-Source';
import { CreateDetailResto, MyCustomLoader } from '../templates/template-creator';
import likeButtons from '../../utils/LikeButtons';
import FavRestoIdb from '../../data/FavResto-idb';
import NewReview from '../../utils/NewReview';

const details = {
  async render() {
    return `
        <div class="load"></div>
        <article class="content">
          <div id="likeButtonContainer"></div>
          <div class="customer-reviews">
          <h2>Review</h2>
            <div class="review-form">
              <div class="input-form">
                <div class="review-form-name">
                    <input type="text" name="nama" id="reviewerName" placeholder="Input your name" required>
                </div>
                <div class="review-form-content">
                    <textarea name="content" id="reviewContent" placeholder="Input your review" required></textarea>
                </div>
              </div>
              <button class="submit-btn" id="submit" aria-label="Submit my review">Submit</button>
            </div>
            <div id="result"></div>
          </div>
        </article>
        `;
  },

  async afterRender() {
    const load = document.querySelector('.load');
    const content = document.querySelector('.content');
    const resultContainer = document.querySelector('#result');
    const url = urlParser.parseActiveUrlWithoutCombiner();
    content.style.display = 'none';
    load.innerHTML = MyCustomLoader();
    try {
      const result = await KuyRestoSource.restaurantListDetail(url.id);
      resultContainer.innerHTML = CreateDetailResto(result.restaurant);
      NewReview.post(url);
      likeButtons.init({
        likeButtonContainer: document.querySelector('#likeButtonContainer'),
        favoriteRestaurant: FavRestoIdb,
        restaurant: {
          id: result.restaurant.id,
          name: result.restaurant.name,
          address: result.restaurant.address,
          city: result.restaurant.city,
          categories: result.restaurant.categories,
          menus: result.restaurant.menus,
          rating: result.restaurant.rating,
          pictureId: result.restaurant.pictureId,
          description: result.restaurant.description,
          customerReviews: result.restaurant.customerReviews,
        },
      });
      content.style.display = 'block';
      load.style.display = 'none';
    } catch (error) {
      content.style.display = 'block';
      load.style.display = 'none';
      content.innerHTML = `<b>Error: please check your internet connection...</b> ${error}`;
    }
  },
};

export default details;
