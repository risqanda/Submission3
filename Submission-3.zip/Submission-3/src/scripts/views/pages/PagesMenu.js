/* eslint-disable linebreak-style */
import KuyRestoSource from '../../data/KuyResto-Source';
import {
  CreateCardResto,
  MyCustomLoader,
  CreateSkeletonTemplate,
} from '../templates/template-creator';

const MenuApp = {
  async render() {
    return `
            <div class="load"></div>
            <section class="content-wrapper">
                <h2>Explore <span>Restaurant</span></h2>
                <div class="card-list" id="card-data">
                    <!-- Card Fill -->
                    ${CreateSkeletonTemplate(20)}
                </div>
            </section>
        `;
  },

  async afterRender() {
    const load = document.querySelector('.load');
    const content = document.querySelector('.content-wrapper');
    const restoContainer = document.querySelector('#card-data');
    content.style.display = 'none';
    load.innerHTML = MyCustomLoader();

    try {
      const restaurant = await KuyRestoSource.restaurantList();
      restoContainer.innerHTML = '';
      restaurant.forEach((resto) => {
        restoContainer.innerHTML += CreateCardResto(resto);
      });
      content.style.display = 'block';
      load.style.display = 'none';
    } catch (error) {
      content.style.display = 'block';
      load.style.display = 'none';
      content.innerHTML = `<b>Error: Please check your connection...</b> ${error}`;
    }
  },
};

export default MenuApp;
