import KuyRestoSource from '../data/KuyResto-Source';
import { CreateCardReview } from '../views/templates/template-creator';

const newReview = {
  post(url) {
    const submitButton = document.querySelector('#submit');
    const reviewerNameInput = document.querySelector('#reviewerName');
    const reviewContentInput = document.querySelector('#reviewContent');

    submitButton.addEventListener('click', async () => {
      const newReviewData = {
        id: url.id,
        name: reviewerNameInput.value,
        review: reviewContentInput.value,
      };

      if (!!newReviewData.name && !!newReviewData.review) {
        const reviewContainer = document.querySelector('.review-detail');
        try {
          const response = await KuyRestoSource.restaurantReview(newReviewData);
          KuyRestoSource.restaurantListDetail(url.id);
          reviewContainer.innerHTML = CreateCardReview(response.customerReview);
        } catch (error) {
          reviewContainer.innerHTML = `<b>Error: Please check your connection...</b> ${error}`;
        }
      }
      this.emptyReview();
    });
  },

  emptyReview() {
    document.querySelector('#reviewerName').value = '';
    document.querySelector('#reviewContent').value = '';
  },
};

export default newReview;
