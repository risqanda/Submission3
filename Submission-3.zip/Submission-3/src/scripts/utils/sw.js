/* eslint-disable linebreak-style */
/* eslint-disable no-restricted-globals */
import 'regenerator-runtime';
import Cache from './Cache';

const { assets } = global.serviceWorkerOption;

self.addEventListener('install', (event) => {
  event.waitUntil(Cache.cachingAppShell([...assets, './']));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(Cache.deleteOldCache());
});

self.addEventListener('fetch', (event) => {
  event.respondWith(Cache.revalidateCache(event.request));
});
