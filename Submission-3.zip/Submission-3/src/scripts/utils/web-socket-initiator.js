/* eslint-disable linebreak-style */
/* eslint-disable indent */
/* eslint-disable no-underscore-dangle */
import NotificationApp from './Notif';

let socket = null;

const webSocketInitiator = {
    init(url) {
        socket = new WebSocket(url);
        console.log('Web Socket connected to => ', socket.url);

        socket.onmessage = this._onMessageInitiate;
    },

    _onMessageInitiate(message) {
        console.log('Web Socket on message initiator => ', message);

        const reviewData = JSON.parse(message.data);

        NotificationApp.sendNotification({
            title: reviewData.name,
            option: {
                body: reviewData.review,
                icon: '../../public/images/logo/logo.png,',
                image: reviewData.image,
                vibrate: [200, 100, 200],
            },
        });
    },
};

const sendDataToWebSocket = (reviewData) => {
    const data = JSON.stringify(reviewData);

    socket.send(data);
};

export { webSocketInitiator, sendDataToWebSocket };
