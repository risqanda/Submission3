/* eslint-disable linebreak-style */
/* eslint-disable no-underscore-dangle */
import { CreateLikeButtonTemplate, CreateLikedButtonTemplate } from '../views/templates/template-creator';

const likeButtons = {
  async init({ likeButtonContainer, favoriteRestaurant, restaurant }) {
    this.likeButtonContainer = likeButtonContainer;
    this.favoriteRestaurant = favoriteRestaurant;
    this.restaurant = restaurant;

    await this.renderButton();
  },

  async renderButton() {
    if (this.restaurant && this.restaurant.id) {
      const { id } = this.restaurant;

      if (await this.isRestaurantExist(id)) {
        this.renderLiked();
      } else {
        this.renderLike();
      }
    }
  },

  async isRestaurantExist(id) {
    const resto = await this.favoriteRestaurant.getResto(id);
    return resto !== undefined && resto !== null;
  },

  renderLike() {
    this.likeButtonContainer.innerHTML = CreateLikeButtonTemplate();
    const likeButton = document.querySelector('#likeButton');
    likeButton.addEventListener('click', async () => {
      await this.favoriteRestaurant.putResto(this.restaurant);
      this.renderButton();
    });
  },

  renderLiked() {
    this.likeButtonContainer.innerHTML = CreateLikedButtonTemplate();
    const likedButton = document.querySelector('#likedButton');
    likedButton.addEventListener('click', async () => {
      await this.favoriteRestaurant.deleteResto(this.restaurant.id);
      this.renderButton();
    });
  },
};

export default likeButtons;
