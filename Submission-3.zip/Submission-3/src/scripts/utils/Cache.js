/* eslint-disable linebreak-style */
/* eslint-disable no-underscore-dangle */
import CONFIG from '../globals/config';

const Cache = {
  async _addCache(request) {
    const cache = await this._openCache();
    cache.add(request);
  },

  async _fetchRequest(request) {
    const fetchresponse = await fetch(request);

    if (!fetchresponse || fetchresponse.status !== 200) {
      return fetchresponse;
    }

    await this._addCache(request);
    return fetchresponse;
  },

  async cachingAppShell(request) {
    const cache = await this._openCache();
    cache.addAll(request);
  },

  async revalidateCache(request) {
    const revalresponse = await caches.match(request);

    if (revalresponse) {
      return revalresponse;
    }
    return this._fetchRequest(request);
  },

  async deleteOldCache() {
    const cacheName = await caches.keys();
    cacheName
      .filter((name) => name !== CONFIG.CACHE_NAME)
      .map((filteredName) => caches.delete(filteredName));
  },

  async _openCache() {
    return caches.open(CONFIG.CACHE_NAME);
  },

};
export default Cache;
