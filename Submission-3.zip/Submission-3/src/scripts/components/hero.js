class HeroContent extends HTMLElement {
  connectedCallback() {
    this.render();
  }

  render() {
    this.innerHTML = `
    <div class="hero-img">
      <picture>
        <source media="(max-width: 600px)" srcset="./images/heros/hero-image_small.jpg">
        <source media="(min-width: 601px)" srcset="./images/heros/hero-image_large.jpg">
      </picture>
      <div class="hero">
        <h1 class="fade-in">"Kuy Resto, Teman Dikala Lapar Mengundang"</h1>
      </div>
    </div>
    `;
  }
}

customElements.define('hero-app', HeroContent);
