/* eslint-disable linebreak-style */
class FooterContent extends HTMLElement {
  connectedCallback() {
    this.render();
  }

  render() {
    this.innerHTML = `
            <footer>
            <p>
              &copy; Copyright 2023 &dash; <a href="/">Kuy Resto</a> | 
              <a href="https://github.com/risqanda" target="_blank" >View on Github</a>
            </p>
          </footer>
            `;
  }
}
customElements.define('footer-app', FooterContent);
