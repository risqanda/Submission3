/* eslint-disable no-undef */
// eslint-disable-next-line import/named
import itActsAsFavoriteRestoModel from './contract/favRestorContract';
import FavRestoIdb from '../src/scripts/data/FavResto-idb';

describe('Favorite Movie Idb Contract Test Implementation', () => {
  afterEach(async () => {
    (await FavRestoIdb.getAllResto()).forEach(async (resto) => {
      await FavRestoIdb.deleteResto(resto.id);
    });
  });

  itActsAsFavoriteRestoModel(FavRestoIdb);
});
