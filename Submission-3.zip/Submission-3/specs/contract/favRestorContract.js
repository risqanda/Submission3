/* eslint-disable no-undef */
const itActsAsFavoriteRestoModel = (favoriteRestaurant) => {
  it('should return the restaurant that has been added', async () => {
    await favoriteRestaurant.putResto({ id: 1 });
    await favoriteRestaurant.putResto({ id: 2 });

    expect(await favoriteRestaurant.getResto(1)).toEqual({ id: 1 });
    expect(await favoriteRestaurant.getResto(2)).toEqual({ id: 2 });
    expect(await favoriteRestaurant.getResto(3)).toBe();
  });

  it('should be able to delete a restaurant', async () => {
    await favoriteRestaurant.putResto({ id: 1 });
    await favoriteRestaurant.putResto({ id: 2 });
    await favoriteRestaurant.putResto({ id: 3 });

    await favoriteRestaurant.deleteResto(1);

    expect(await favoriteRestaurant.getAllResto()).toEqual([{ id: 2 }, { id: 3 }]);
  });

  it('should be able to return all of the added restaurants', async () => {
    await favoriteRestaurant.putResto({ id: 1 });
    await favoriteRestaurant.putResto({ id: 2 });

    expect(await favoriteRestaurant.getAllResto()).toEqual([{ id: 1 }, { id: 2 }]);
  });
};

export default itActsAsFavoriteRestoModel;
